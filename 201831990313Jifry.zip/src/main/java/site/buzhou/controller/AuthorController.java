package site.buzhou.controller;

import org.springframework.stereotype.Controller;

/**
 * @program: Jifry
 * @description:
 * @author: 不周
 * @create: 2020-12-10 15:10
 **/
@Controller
public class AuthorController {
}

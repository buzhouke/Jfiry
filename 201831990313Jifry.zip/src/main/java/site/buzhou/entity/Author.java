package site.buzhou.entity;

/**
 * @program: Jifry
 * @description: author
 * @author: 不周
 * @create: 2020-12-09 21:23
 **/
public class Author {
    public String email;
    private String password;
}

package site.buzhou.entity;

/**
 * @program: Jifry
 * @description: Administrator class
 * @author: 不周
 * @create: 2020-12-09 21:19
 **/
public class Administrator {
    private String email, password;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
